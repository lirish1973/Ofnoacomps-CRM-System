<?php
/**
 * Plugin Name: Ofnoacomps Post Badges
 * Plugin URI:  https://www.ofnoacomps.co.il
 * Description: מוסיף Badge (תווית) על תמונת הפוסט עם שליטה מלאה על עיצוב, מיקום וצבעים. עובד עם Elementor Loop, תמות קלאסיות ובלוקים.
 * Version:     1.0.3
 * Author:      Ofnoacomps
 * Text Domain: ofnoacomps-postbadges
 * Domain Path: /languages
 */

defined( 'ABSPATH' ) || exit;

define( 'OPB_VERSION', '1.0.3' );
define( 'OPB_DIR',     plugin_dir_path( __FILE__ ) );
define( 'OPB_URL',     plugin_dir_url( __FILE__ ) );
define( 'OPB_FILE',    __FILE__ );
define( 'OPB_OPTION',  'opb_settings' );

// ── Default settings ────────────────────────────────────────────────────────
if ( ! function_exists( 'opb_defaults' ) ) {
    function opb_defaults() {
        return [
            'enabled'       => 1,
            'default_text'  => 'חדש!',
            'type'          => 'square',
            'position'      => 'top-right',
            'bg_color'      => '#e74c3c',
            'text_color'    => '#ffffff',
            'font_size'     => 14,
            'text_shadow'   => 1,
            'shadow_color'  => 'rgba(0,0,0,0.35)',
            'border_radius' => 6,
            'filter_mode'   => 'all',
            'filter_terms'  => [],
        ];
    }
}

// Always merge saved option with defaults (works even without activation hook)
if ( ! function_exists( 'opb_get_settings' ) ) {
    function opb_get_settings() {
        return wp_parse_args( (array) get_option( OPB_OPTION, [] ), opb_defaults() );
    }
}

// ── Auto-updater ────────────────────────────────────────────────────────────
require_once OPB_DIR . 'includes/class-github-updater.php';
new OPB_GitHub_Updater( OPB_FILE, 'ofnoacomps-postBadges', OPB_VERSION );

// ── Core ────────────────────────────────────────────────────────────────────
require_once OPB_DIR . 'includes/class-badge-renderer.php';
require_once OPB_DIR . 'includes/class-meta-box.php';

// ── Admin ───────────────────────────────────────────────────────────────────
if ( is_admin() ) {
    require_once OPB_DIR . 'admin/class-admin.php';
    new OPB_Admin();
}

new OPB_Meta_Box();

// ── Frontend assets ─────────────────────────────────────────────────────────
add_action( 'wp_enqueue_scripts', 'opb_enqueue_frontend' );
function opb_enqueue_frontend() {
    $s = opb_get_settings();
    if ( empty( $s['enabled'] ) ) return;

    wp_enqueue_style(  'opb-frontend', OPB_URL . 'assets/frontend.css', [], OPB_VERSION );
    wp_enqueue_script( 'opb-frontend', OPB_URL . 'assets/frontend.js',  [], OPB_VERSION, true );
}

/**
 * APPROACH: add data-opb-* attributes to the <img> tag via wp_get_attachment_image_attributes.
 * This fires for EVERY WordPress image render — including Elementor Loop, Posts widgets,
 * Gutenberg blocks, classic themes — because they all ultimately call wp_get_attachment_image().
 * A small JS then wraps eligible images with the badge overlay.
 */
if ( ! function_exists( 'opb_add_badge_attrs' ) ) {
    add_filter( 'wp_get_attachment_image_attributes', 'opb_add_badge_attrs', 20, 3 );
    function opb_add_badge_attrs( $attr, $attachment, $size ) {
        // Guard: must be a valid array
        if ( ! is_array( $attr ) ) return $attr;

        // Guard: attachment must be a valid object with ID
        if ( ! is_object( $attachment ) || empty( $attachment->ID ) ) return $attr;

        // Skip admin
        if ( is_admin() ) return $attr;

        $s = opb_get_settings();
        if ( empty( $s['enabled'] ) ) return $attr;

        // Determine current post context
        $post_id = (int) get_the_ID();
        if ( ! $post_id ) {
            global $post;
            $post_id = ( isset( $post ) && is_object( $post ) && ! empty( $post->ID ) )
                ? (int) $post->ID : 0;
        }
        if ( ! $post_id ) return $attr;

        // Only featured images
        $thumb_id = (int) get_post_thumbnail_id( $post_id );
        if ( ! $thumb_id || $thumb_id !== (int) $attachment->ID ) return $attr;

        // Per-post: disabled?
        if ( get_post_meta( $post_id, '_opb_disabled', true ) ) return $attr;

        // Category / Tag filter
        $filter_mode  = isset( $s['filter_mode'] ) ? $s['filter_mode'] : 'all';
        $filter_terms = isset( $s['filter_terms'] ) ? (array) $s['filter_terms'] : [];

        if ( $filter_mode !== 'all' && ! empty( $filter_terms ) ) {
            $term_ids = array_map( 'intval', $filter_terms );

            if ( $filter_mode === 'categories' ) {
                $cats = wp_get_post_categories( $post_id, [ 'fields' => 'ids' ] );
                if ( empty( array_intersect( $term_ids, (array) $cats ) ) ) return $attr;
            } elseif ( $filter_mode === 'tags' ) {
                $tags = wp_get_post_tags( $post_id, [ 'fields' => 'ids' ] );
                if ( empty( array_intersect( $term_ids, (array) $tags ) ) ) return $attr;
            }
        }

        // Badge text: per-post → global default
        $text = (string) get_post_meta( $post_id, '_opb_text', true );
        if ( $text === '' ) $text = isset( $s['default_text'] ) ? (string) $s['default_text'] : '';
        if ( $text === '' ) return $attr;

        // Per-post style overrides
        $type   = get_post_meta( $post_id, '_opb_type',     true ) ?: ( isset( $s['type'] )     ? $s['type']     : 'square' );
        $pos    = get_post_meta( $post_id, '_opb_position', true ) ?: ( isset( $s['position'] )  ? $s['position'] : 'top-right' );
        $bg     = get_post_meta( $post_id, '_opb_bg',       true ) ?: ( isset( $s['bg_color'] )  ? $s['bg_color'] : '#e74c3c' );
        $color  = get_post_meta( $post_id, '_opb_color',    true ) ?: ( isset( $s['text_color'] ) ? $s['text_color'] : '#ffffff' );
        $fsize  = iss