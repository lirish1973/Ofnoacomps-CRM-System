<?php
/**
 * Plugin Name: Ofnoacomps Post Badges
 * Plugin URI:  https://www.ofnoacomps.co.il
 * Description: מוסיף Badge (תווית) על תמונת הפוסט עם שליטה מלאה על עיצוב, מיקום וצבעים. עובד עם Elementor Loop, תמות קלאסיות ובלוקים.
 * Version:     1.0.2
 * Author:      Ofnoacomps
 * Text Domain: ofnoacomps-postbadges
 * Domain Path: /languages
 */

defined( 'ABSPATH' ) || exit;

define( 'OPB_VERSION', '1.0.2' );
define( 'OPB_DIR',     plugin_dir_path( __FILE__ ) );
define( 'OPB_URL',     plugin_dir_url( __FILE__ ) );
define( 'OPB_FILE',    __FILE__ );
define( 'OPB_OPTION',  'opb_settings' );

// ── Default settings ────────────────────────────────────────────────────────
function opb_defaults() {
    return [
        'enabled'       => 1,
        'default_text'  => 'חדש!',
        'type'          => 'square',
        'position'      => 'top-right',
        'bg_color'      => '#e74c3c',
        'text_color'    => '#ffffff',
        'font_size'     => 14,
        'text_shadow'   => 1,
        'shadow_color'  => 'rgba(0,0,0,0.35)',
        'border_radius' => 6,
        // Filtering
        'filter_mode'   => 'all',   // 'all' | 'categories' | 'tags'
        'filter_terms'  => [],      // array of term IDs
    ];
}

// Always merge saved option with defaults (works even without activation hook)
function opb_get_settings() {
    return wp_parse_args( (array) get_option( OPB_OPTION, [] ), opb_defaults() );
}

// ── Auto-updater ────────────────────────────────────────────────────────────
require_once OPB_DIR . 'includes/class-github-updater.php';
new OPB_GitHub_Updater( OPB_FILE, 'ofnoacomps-postBadges', OPB_VERSION );

// ── Core ────────────────────────────────────────────────────────────────────
require_once OPB_DIR . 'includes/class-badge-renderer.php';
require_once OPB_DIR . 'includes/class-meta-box.php';

// ── Admin ───────────────────────────────────────────────────────────────────
if ( is_admin() ) {
    require_once OPB_DIR . 'admin/class-admin.php';
    new OPB_Admin();
}

new OPB_Meta_Box();

// ── Frontend assets ─────────────────────────────────────────────────────────
add_action( 'wp_enqueue_scripts', 'opb_enqueue_frontend' );
function opb_enqueue_frontend() {
    $s = opb_get_settings();
    if ( empty( $s['enabled'] ) ) return;

    wp_enqueue_style(  'opb-frontend', OPB_URL . 'assets/frontend.css', [], OPB_VERSION );
    wp_enqueue_script( 'opb-frontend', OPB_URL . 'assets/frontend.js',  [], OPB_VERSION, true );
}

/**
 * APPROACH: add data-opb-* attributes to the <img> tag