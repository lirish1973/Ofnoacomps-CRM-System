<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SCR_Tracker {

    /** מונע רישום כפול של shutdown hook */
    private static bool $save_scheduled = false;

    public static function init(): void {
        // מעקב אחר שינויים בעגלה
        add_action( 'woocommerce_add_to_cart',            [ __CLASS__, 'on_cart_updated' ] );
        add_action( 'woocommerce_cart_item_removed',      [ __CLASS__, 'on_cart_updated' ] );
        add_action( 'woocommerce_cart_item_set_quantity',  [ __CLASS__, 'on_cart_updated' ] );

        // סימון שחזור בעת השלמת הזמנה
        add_action( 'woocommerce_thankyou',                [ __CLASS__, 'on_order_complete' ] );
        add_action( 'woocommerce_order_status_processing', [ __CLASS__, 'on_order_complete' ] );
        add_action( 'woocommerce_order_status_completed',  [ __CLASS__, 'on_order_complete' ] );

        // לכידת אימייל/טלפון מדף ה-Checkout
        add_action( 'woocommerce_checkout_update_order_review', [ __CLASS__, 'on_checkout_update' ] );
    }

    /**
     * ✅ תיקון: כעת מוסיף shutdown hook רק פעם אחת,
     *    גם אם on_cart_updated() נקרא מספר פעמים בבקשה אחת.
     */
    public static function on_cart_updated(): void {
        if ( ! self::$save_scheduled ) {
            self::$save_scheduled = true;
            add_action( 'shutdown', [ __CLASS__, 'save_cart' ] );
        }
    }

    public static function save_cart(): void {
        if ( ! WC() || ! WC()->cart ) return;

        if ( WC()->cart->is_empty() ) {
            // עגלה ריקה – סמן כ"רוקנה"
            $session_id = self::get_session_id();
            if ( $session_id ) {
                global $wpdb;
                $wpdb->update(
                    $wpdb->prefix . SCR_TABLE,
                    [ 'status' => 'emptied' ],
                    [ 'session_id' => $session_id, 'status' => 'abandoned' ]
                );
            }
            return;
        }

        $user_id    = get_current_user_id();
        $session_id = self::get_session_id();
        $customer   = WC()->customer;

        // שליפת פרטי לקוח
        if ( $user_id ) {
            $user_data  = get_userdata( $user_id );
            $email      = $user_data ? $user_data->user_email : '';
            $phone      = (string) get_user_meta( $user_id, 'billing_phone', true );
            $first_name = (string) get_user_meta( $user_id, 'billing_first_name', true );
        } else {
            $email      = $customer ? $customer->get_billing_email() : '';
            $phone      = $customer ? $customer->get_billing_phone() : '';
            $first_name = $customer ? $customer->get_billing_first_name() : '';
        }

        // בניית רשימת פריטי העגלה
        $items = [];
        foreach ( WC()->cart->get_cart() as $cart_item ) {
            /** @var WC_Product $product */
            $product = $cart_item['data'];
            if ( ! $product ) continue;
            $items[] = [
                'name'  => $product->get_name(),
                'qty'   => $cart_item['quantity'],
                'price' => wc_price( $product->get_price() ),
                'image' => wp_get_attachment_url( $product->get_image_id() ) ?: '',
            ];
        }

        SCR_DB::upsert_cart( [
            'user_id'       => $user_id ?: 0,
            'session_id'    => $session_id,
            'email'         => sanitize_email( $email ),
            'phone'         => sanitize_text_field( $phone ),
            'first_name'    => sanitize_text_field( $first_name ?: __( 'אורח יקר', 'smart-cart-recovery' ) ),
            'cart_total'    => WC()->cart->get_cart_contents_total(),
            'cart_contents' => wp_json_encode( $items, JSON_UNESCAPED_UNICODE ),
            'cart_url'      => wc_get_cart_url(),
            'last_activity' => current_time( 'mysql' ),
            'status'        => 'abandoned',
        ] );
    }

    public static function on_order_complete( $order_id ): void {
        $order = wc_get_order( $order_id );
        if ( ! $order ) return;

        $user_id = $order->get_user_id();
        $email   = $order->get_billing_email();

        if ( $user_id ) {
            SCR_DB::mark_recovered( $user_id, 'user_id' );
        }
        if ( $email ) {
            SCR_DB::mark_recovered( sanitize_email( $email ), 'email' );
        }
    }

    public static function on_checkout_update( string $post_data ): void {
        parse_str( $post_data, $data );

        $email = sanitize_email( $data['billing_email'] ?? '' );
        $phone = sanitize_text_field( $data['billing_phone'] ?? '' );
        $name  = sanitize_text_field( $data['billing_first_name'] ?? '' );

        if ( ! $email && ! $phone ) return;

        $session_id = self::get_session_id();
        if ( ! $session_id ) return;

        $update = array_filter( [
            'email'      => $email,
            'phone'      => $phone,
            'first_name' => $name,
        ] );

        if ( empty( $update ) ) return;

        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . SCR_TABLE,
            $update,
            [ 'session_id' => $session_id, 'status' => 'abandoned' ]
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // עזר
    // ─────────────────────────────────────────────────────────────────────────

    private static function get_session_id(): string {
        if ( ! WC() || ! WC()->session ) return '';
        return (string) WC()->session->get_customer_id();
    }
}
