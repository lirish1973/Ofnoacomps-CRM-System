<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SCR_Cron {

    // עיתוי ה-Sequence (בשעות)
    const STEP1_HOURS = 1;
    const STEP2_HOURS = 24;
    const STEP3_HOURS = 72;

    // מגבלת עגלות לעיבוד בכל הרצה (מונע timeout)
    const BATCH_SIZE = 50;

    public static function init(): void {
        add_filter( 'cron_schedules', [ __CLASS__, 'add_intervals' ] );

        if ( ! wp_next_scheduled( 'scr_process_carts' ) ) {
            wp_schedule_event( time(), 'every_15_min', 'scr_process_carts' );
        }

        add_action( 'scr_process_carts',       [ __CLASS__, 'process' ] );
        add_action( 'wp_ajax_scr_manual_run',  [ __CLASS__, 'ajax_manual_run' ] );
    }

    public static function add_intervals( array $schedules ): array {
        $schedules['every_15_min'] = [
            'interval' => 900,
            'display'  => __( 'כל 15 דקות', 'smart-cart-recovery' ),
        ];
        return $schedules;
    }

    public static function process(): void {
        $opts = (array) get_option( 'scr_settings', [] );

        $channels = [
            'whatsapp' => ! empty( $opts['enable_whatsapp'] ),
            'sms'      => ! empty( $opts['enable_sms'] ),
            'email'    => ! empty( $opts['enable_email'] ),
        ];

        // אם אין אף ערוץ פעיל – אין מה לעשות
        if ( ! in_array( true, $channels, true ) ) return;

        $batch = apply_filters( 'scr_batch_size', self::BATCH_SIZE );

        self::run_step( 1, self::STEP1_HOURS, $channels, $opts, $batch );
        self::run_step( 2, self::STEP2_HOURS, $channels, $opts, $batch );
        self::run_step( 3, self::STEP3_HOURS, $channels, $opts, $batch );

        update_option( 'scr_last_cron_run', current_time( 'mysql' ) );
    }

    private static function run_step( int $step, int $hours, array $channels, array $opts, int $batch ): void {
        if ( empty( $opts[ "enable_step{$step}" ] ) ) return;

        $carts = SCR_DB::get_abandoned_carts( $step, $hours, $batch );
        if ( empty( $carts ) ) return;

        foreach ( $carts as $cart ) {
            $sent = false;

            // סדר עדיפויות: WhatsApp → SMS → Email
            if ( $channels['whatsapp'] && ! empty( $cart->phone ) ) {
                $sent = SCR_Sender::send_whatsapp( $cart, $step );
            }

            if ( ! $sent && $channels['sms'] && ! empty( $cart->phone ) ) {
                $sent = SCR_Sender::send_sms( $cart, $step );
            }

            // אימייל נשלח תמיד (במקביל ל-WhatsApp/SMS אם מוגדר כך)
            if ( $channels['email'] && ! empty( $cart->email ) ) {
                $email_sent = SCR_Sender::send_email( $cart, $step );
                $sent       = $sent || $email_sent;
            }

            if ( $sent ) {
                SCR_DB::mark_step_sent( (int) $cart->id, $step );
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // הרצה ידנית מה-Dashboard (AJAX)
    // ─────────────────────────────────────────────────────────────────────────

    public static function ajax_manual_run(): void {
        check_ajax_referer( 'scr_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_woocommerce' ) ) wp_die( 'Unauthorized', 403 );

        self::process();

        wp_send_json_success( [
            'message' => __( 'התהליך הושלם בהצלחה!', 'smart-cart-recovery' ),
            'time'    => current_time( 'H:i:s' ),
        ] );
    }

    public static function unschedule(): void {
        $timestamp = wp_next_scheduled( 'scr_process_carts' );
        if ( $timestamp ) {
            wp_unschedule_event( $timestamp, 'scr_process_carts' );
        }
    }
}
