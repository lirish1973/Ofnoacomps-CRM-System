<?php
/**
 * Uninstall Smart Cart Recovery
 * נמחק רק כאשר המשתמש מוחק את הפלאגין מהדשבורד – לא בעת הכיבוי.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// טעינת מחלקת ה-DB בלבד
require_once plugin_dir_path( __FILE__ ) . 'includes/class-scr-db.php';

// מחיקת טבלאות ואפשרויות רק אם המשתמש אישר זאת בהגדרות
$opts = get_option( 'scr_settings', [] );
if ( ! empty( $opts['delete_data_on_uninstall'] ) ) {
    SCR_DB::drop_tables();
}

// ניקוי cron
wp_clear_scheduled_hook( 'scr_process_carts' );
