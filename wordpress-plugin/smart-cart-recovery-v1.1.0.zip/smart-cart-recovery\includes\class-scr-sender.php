<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SCR_Sender {

    private static function opts(): array {
        return (array) get_option( 'scr_settings', [] );
    }

    // ═══════════════════════════════════════════════════════════════════════
    // WhatsApp (Twilio)
    // ═══════════════════════════════════════════════════════════════════════

    public static function send_whatsapp( object $cart, int $step ): bool {
        $opts  = self::opts();
        $sid   = $opts['twilio_sid']    ?? '';
        $token = $opts['twilio_token']  ?? '';
        $from  = $opts['twilio_wa_from'] ?? 'whatsapp:+14155238886';

        if ( ! $sid || ! $token || empty( $cart->phone ) ) return false;

        // ✅ תיקון: ולידציה של מספר טלפון לפני שליחה
        $phone = self::format_il_phone( $cart->phone );
        if ( ! $phone ) return false;

        $message = self::build_message( $cart, $step, 'whatsapp' );

        $url  = "https://api.twilio.com/2010-04-01/Accounts/{$sid}/Messages.json";
        $args = [
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode( "$sid:$token" ),
                'Content-Type'  => 'application/x-www-form-urlencoded',
            ],
            'body'    => [
                'From' => $from,
                'To'   => "whatsapp:{$phone}",
                'Body' => $message,
            ],
            'timeout' => 15,
        ];

        $response = wp_remote_post( $url, $args );
        [ $status, $body ] = self::parse_twilio_response( $response );

        SCR_DB::log_send( (int) $cart->id, 'whatsapp', $phone, $step, $status, $message, $body );
        return $status === 'sent';
    }

    // ═══════════════════════════════════════════════════════════════════════
    // SMS (Twilio)
    // ═══════════════════════════════════════════════════════════════════════

    public static function send_sms( object $cart, int $step ): bool {
        $opts  = self::opts();
        $sid   = $opts['twilio_sid']      ?? '';
        $token = $opts['twilio_token']    ?? '';
        $from  = $opts['twilio_sms_from'] ?? '';

        if ( ! $sid || ! $token || ! $from || empty( $cart->phone ) ) return false;

        // ✅ תיקון: ולידציה של מספר טלפון לפני שליחה
        $phone = self::format_il_phone( $cart->phone );
        if ( ! $phone ) return false;

        $message = self::build_message( $cart, $step, 'sms' );

        $url  = "https://api.twilio.com/2010-04-01/Accounts/{$sid}/Messages.json";
        $args = [
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode( "$sid:$token" ),
                'Content-Type'  => 'application/x-www-form-urlencoded',
            ],
            'body'    => [
                'From' => $from,
                'To'   => $phone,
                'Body' => $message,
            ],
            'timeout' => 15,
        ];

        $response = wp_remote_post( $url, $args );
        [ $status, $body ] = self::parse_twilio_response( $response );

        SCR_DB::log_send( (int) $cart->id, 'sms', $phone, $step, $status, $message, $body );
        return $status === 'sent';
    }

    // ═══════════════════════════════════════════════════════════════════════
    // אימייל
    // ═══════════════════════════════════════════════════════════════════════

    public static function send_email( object $cart, int $step ): bool {
        if ( empty( $cart->email ) || ! is_email( $cart->email ) ) return false;

        $opts    = self::opts();
        $subject = self::parse_template(
            $opts[ "email_subject_step{$step}" ] ?? self::default_subject( $step ),
            $cart
        );
        $body = self::build_message( $cart, $step, 'email' );

        // ✅ תיקון: בדיקה אם התבנית כבר מכילה HTML לפני nl2br
        $has_html = $body !== strip_tags( $body );
        if ( ! $has_html ) {
            $body = nl2br( esc_html( $body ) );
        }

        // עטיפת גוף ה-HTML במבנה בסיסי אם אין תגית <html>
        if ( stripos( $body, '<html' ) === false ) {
            $shop_name = esc_html( get_bloginfo( 'name' ) );
            $body = "<!DOCTYPE html><html dir=\"rtl\"><head><meta charset=\"UTF-8\"></head>
<body style=\"font-family:Arial,sans-serif;direction:rtl;padding:24px;color:#333;\">
<div style=\"max-width:600px;margin:0 auto;\">
{$body}
<hr style=\"margin:32px 0;border:none;border-top:1px solid #eee;\">
<p style=\"font-size:12px;color:#999;\">{$shop_name}</p>
</div>
</body></html>";
        }

        $from_name  = $opts['email_from_name'] ?? get_bloginfo( 'name' );
        $from_email = $opts['email_from']      ?? get_option( 'admin_email' );

        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            "From: {$from_name} <{$from_email}>",
        ];

        $sent = wp_mail( $cart->email, $subject, $body, $headers );
        SCR_DB::log_send( (int) $cart->id, 'email', $cart->email, $step, $sent ? 'sent' : 'error', $subject, '' );
        return $sent;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // בניית הודעה
    // ═══════════════════════════════════════════════════════════════════════

    private static function build_message( object $cart, int $step, string $channel ): string {
        $opts     = self::opts();
        $key      = "{$channel}_template_step{$step}";
        $template = $opts[ $key ] ?? self::default_template( $step, $channel );
        return self::parse_template( $template, $cart );
    }

    public static function parse_template( string $template, object $cart ): string {
        $items_text = '';
        if ( ! empty( $cart->cart_contents ) ) {
            $items = json_decode( $cart->cart_contents, true );
            if ( is_array( $items ) ) {
                foreach ( $items as $item ) {
                    $items_text .= "• " . esc_html( $item['name'] ?? '' )
                        . " x" . intval( $item['qty'] ?? 1 )
                        . " – " . ( $item['price'] ?? '' ) . "\n";
                }
            }
        }

        $cart_url   = ! empty( $cart->cart_url ) ? $cart->cart_url : ( function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : '' );
        $cart_total = function_exists( 'wc_price' ) ? wc_price( $cart->cart_total ) : number_format( (float) $cart->cart_total, 2 ) . ' ₪';

        $replacements = [
            '{name}'       => $cart->first_name ?: __( 'אורח יקר', 'smart-cart-recovery' ),
            '{cart_url}'   => esc_url( $cart_url ),
            '{cart_total}' => $cart_total,
            '{items}'      => $items_text,
            '{shop_name}'  => get_bloginfo( 'name' ),
        ];

        return str_replace( array_keys( $replacements ), array_values( $replacements ), $template );
    }

    // ═══════════════════════════════════════════════════════════════════════
    // תבניות ברירת מחדל
    // ═══════════════════════════════════════════════════════════════════════

    public static function default_template( int $step, string $channel ): string {
        $templates = [
            1 => [
                'whatsapp' => "שלום {name}! 🛒\nנראה שהשארת עגלת קניות מלאה...\n\nהפריטים שלך מחכים לך:\n{items}\nסה\"כ: {cart_total}\n\nלחץ כאן להשלמת הרכישה:\n{cart_url}",
                'sms'      => "שלום {name}, שכחת עגלת קניות ב-{shop_name}! לחץ להשלמה: {cart_url}",
                'email'    => "שלום {name},\n\nנראה שהשארת עגלת קניות מלאה:\n\n{items}\nסה\"כ: {cart_total}\n\nלחץ להשלמת הרכישה:\n{cart_url}\n\nבברכה,\nצוות {shop_name}",
            ],
            2 => [
                'whatsapp' => "שלום {name} 😊\nעגלת הקניות שלך עדיין מחכה לך!\n\n{items}\n💰 סה\"כ: {cart_total}\n\nאנחנו שומרים אותה עוד קצת:\n{cart_url}",
                'sms'      => "שלום {name}, עגלת הקניות ב-{shop_name} עדיין כאן! השלם את הרכישה: {cart_url}",
                'email'    => "שלום {name},\n\nעדיין חושב על הפריטים שנשארו בעגלה?\n\n{items}\nסה\"כ: {cart_total}\n\n{cart_url}\n\nבברכה,\n{shop_name}",
            ],
            3 => [
                'whatsapp' => "שלום {name}, הצעה אחרונה! 🎁\nעגלת הקניות שלך עומדת להתפנות בקרוב 🔔\n\n{items}\n\nלסיום הרכישה:\n{cart_url}",
                'sms'      => "הצעה אחרונה {name}! עגלת הקניות ב-{shop_name} עומדת להתפנות. לסיום: {cart_url}",
                'email'    => "שלום {name},\n\n🎁 הצעה אחרונה! עגלת הקניות שלך עומדת להתפנות בקרוב.\n\n{items}\nסה\"כ: {cart_total}\n\nלסיום הרכישה לחץ כאן:\n{cart_url}\n\nבברכה,\n{shop_name}",
            ],
        ];

        return $templates[ $step ][ $channel ] ?? '';
    }

    // ✅ תיקון: default_subject הופכת ל-public כדי שניתן לקרוא לה מה-admin
    public static function default_subject( int $step ): string {
        $subjects = [
            1 => '🛒 שכחת משהו בעגלת הקניות שלך?',
            2 => '😊 עגלת הקניות שלך עדיין מחכה לך',
            3 => '🎁 הצעה אחרונה – עגלתך עומדת להתפנות',
        ];
        return $subjects[ $step ] ?? __( 'תזכורת', 'smart-cart-recovery' );
    }

    // ═══════════════════════════════════════════════════════════════════════
    // עזר פנימי
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * ✅ תיקון: בדיקת HTTP status code – לא רק WP_Error
     */
    private static function parse_twilio_response( $response ): array {
        if ( is_wp_error( $response ) ) {
            return [ 'error', $response->get_error_message() ];
        }

        $http_code = (int) wp_remote_retrieve_response_code( $response );
        $body      = (string) wp_remote_retrieve_body( $response );
        $status    = ( $http_code >= 200 && $http_code < 300 ) ? 'sent' : 'error';

        return [ $status, $body ];
    }

    /**
     * ✅ תיקון: וולידציה וניקוי מספר טלפון ישראלי.
     *    מחזיר מחרוזת ריקה אם המספר לא תקין.
     */
    private static function format_il_phone( string $phone ): string {
        $phone = preg_replace( '/\D/', '', $phone );

        if ( empty( $phone ) ) return '';

        // המרת קידומת 0 לקוד מדינה ישראלי
        if ( str_starts_with( $phone, '0' ) ) {
            $phone = '972' . substr( $phone, 1 );
        }

        // ולידציה: מינימום 11 ספרות לאחר הוספת קוד מדינה (972 + 8)
        if ( strlen( $phone ) < 11 || strlen( $phone ) > 15 ) {
            return '';
        }

        return '+' . $phone;
    }
}
