<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SCR_DB {

    /** עמודות מותרות לבדיקת step */
    private static $allowed_steps = [ 1, 2, 3 ];

    /** עמודות מותרות ב-mark_recovered */
    private static $allowed_identifier_types = [ 'user_id', 'session_id', 'email' ];

    // ─────────────────────────────────────────────────────────────────────────
    // יצירת טבלאות
    // ─────────────────────────────────────────────────────────────────────────

    public static function create_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();

        // טבלת עגלות נטושות
        $carts = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}" . SCR_TABLE . " (
            id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id       BIGINT UNSIGNED NOT NULL DEFAULT 0,
            session_id    VARCHAR(255) NOT NULL DEFAULT '',
            email         VARCHAR(255) DEFAULT '',
            phone         VARCHAR(50)  DEFAULT '',
            first_name    VARCHAR(100) DEFAULT '',
            cart_total    DECIMAL(10,2) DEFAULT 0,
            cart_contents LONGTEXT,
            cart_url      VARCHAR(500) DEFAULT '',
            last_activity DATETIME NOT NULL,
            step1_sent    TINYINT(1) DEFAULT 0,
            step2_sent    TINYINT(1) DEFAULT 0,
            step3_sent    TINYINT(1) DEFAULT 0,
            status        VARCHAR(20) DEFAULT 'abandoned',
            created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_status        (status),
            INDEX idx_last_activity (last_activity),
            INDEX idx_user          (user_id),
            INDEX idx_session       (session_id(50))
        ) $charset;";

        // טבלת לוג שליחות
        $log = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}" . SCR_LOG_TABLE . " (
            id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            cart_id     BIGINT UNSIGNED NOT NULL,
            channel     VARCHAR(20) NOT NULL,
            recipient   VARCHAR(255) NOT NULL,
            step        TINYINT NOT NULL DEFAULT 1,
            status      VARCHAR(20) DEFAULT 'sent',
            message     TEXT,
            response    TEXT,
            sent_at     DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_cart_id (cart_id),
            INDEX idx_sent_at (sent_at),
            INDEX idx_status  (status)
        ) $charset;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $carts );
        dbDelta( $log );

        update_option( 'scr_db_version', SCR_VERSION );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // מחיקת טבלאות (לשימוש ב-uninstall)
    // ─────────────────────────────────────────────────────────────────────────

    public static function drop_tables() {
        global $wpdb;
        // מחיקת טבלת הלוג קודם (יש מפתח זר לוגי לעגלות)
        $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}" . SCR_LOG_TABLE ); // phpcs:ignore
        $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}" . SCR_TABLE );     // phpcs:ignore
        delete_option( 'scr_settings' );
        delete_option( 'scr_db_version' );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // עגלות – כתיבה וקריאה
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * הוספה או עדכון של עגלה נטושה.
     * מחזיר את ה-ID של הרשומה.
     */
    public static function upsert_cart( array $data ): int {
        global $wpdb;
        $table = $wpdb->prefix . SCR_TABLE;

        $existing = null;
        if ( ! empty( $data['user_id'] ) ) {
            $existing = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM `$table` WHERE user_id = %d AND status = 'abandoned' LIMIT 1",
                $data['user_id']
            ) );
        } elseif ( ! empty( $data['session_id'] ) ) {
            $existing = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM `$table` WHERE session_id = %s AND status = 'abandoned' LIMIT 1",
                $data['session_id']
            ) );
        }

        if ( $existing ) {
            $wpdb->update( $table, $data, [ 'id' => (int) $existing ] );
            return (int) $existing;
        }

        $wpdb->insert( $table, $data );
        return (int) $wpdb->insert_id;
    }

    /**
     * שליפת עגלות נטושות לשלב מסוים.
     *
     * @param int  $step      מספר השלב (1-3)
     * @param int  $hours_ago מינימום שעות מאז פעילות אחרונה
     * @param int  $limit     מגבלת רשומות (למניעת timeout)
     */
    public static function get_abandoned_carts( int $step, int $hours_ago, int $limit = 50 ): array {
        global $wpdb;

        // ✅ אבטחה: וידוא שה-step תקין לפני שימוש בשם עמודה דינמי
        $step = self::validate_step( $step );
        if ( ! $step ) {
            return [];
        }

        $table = $wpdb->prefix . SCR_TABLE;
        $col   = "step{$step}_sent";

        // שלב 2 ו-3 ישלחו רק אם השלב הקודם כבר נשלח
        $prev_step_condition = '';
        if ( $step > 1 ) {
            $prev_col            = 'step' . ( $step - 1 ) . '_sent';
            $prev_step_condition = "AND `$prev_col` = 1";
        }

        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM `$table`
             WHERE status = 'abandoned'
             AND `$col` = 0
             $prev_step_condition
             AND last_activity < DATE_SUB(NOW(), INTERVAL %d HOUR)
             AND (email != '' OR phone != '')
             ORDER BY last_activity ASC
             LIMIT %d",
            $hours_ago,
            $limit
        ) ) ?: [];
    }

    /**
     * סימון שלב נשלח.
     */
    public static function mark_step_sent( int $cart_id, int $step ): void {
        // ✅ אבטחה: וידוא step לפני שימוש בשם עמודה דינמי
        $step = self::validate_step( $step );
        if ( ! $step ) return;

        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . SCR_TABLE,
            [ "step{$step}_sent" => 1 ],
            [ 'id' => $cart_id ]
        );
    }

    /**
     * סימון עגלה כ-"שוחזרה".
     */
    public static function mark_recovered( $identifier, string $type = 'user_id' ): void {
        // ✅ אבטחה: whitelist על שם העמודה כדי למנוע SQL injection
        if ( ! in_array( $type, self::$allowed_identifier_types, true ) ) {
            return;
        }

        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . SCR_TABLE,
            [ 'status' => 'recovered' ],
            [ $type => $identifier, 'status' => 'abandoned' ]
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // לוג שליחות
    // ─────────────────────────────────────────────────────────────────────────

    public static function log_send( int $cart_id, string $channel, string $recipient, int $step, string $status, string $message, string $response ): void {
        global $wpdb;
        $wpdb->insert( $wpdb->prefix . SCR_LOG_TABLE, [
            'cart_id'   => $cart_id,
            'channel'   => sanitize_key( $channel ),
            'recipient' => $recipient,
            'step'      => $step,
            'status'    => $status,
            'message'   => $message,
            'response'  => substr( $response, 0, 1000 ), // מגבלת אורך
        ] );
    }

    public static function get_log( int $limit = 50, int $offset = 0 ): array {
        global $wpdb;
        $log_table  = $wpdb->prefix . SCR_LOG_TABLE;
        $cart_table = $wpdb->prefix . SCR_TABLE;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT l.*, c.email, c.phone, c.first_name, c.cart_total
             FROM `$log_table` l
             LEFT JOIN `$cart_table` c ON c.id = l.cart_id
             ORDER BY l.sent_at DESC
             LIMIT %d OFFSET %d",
            $limit,
            $offset
        ) ) ?: [];
    }

    public static function get_total_log_count(): int {
        global $wpdb;
        return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}" . SCR_LOG_TABLE ); // phpcs:ignore
    }

    // ─────────────────────────────────────────────────────────────────────────
    // סטטיסטיקות
    // ─────────────────────────────────────────────────────────────────────────

    public static function get_stats(): array {
        global $wpdb;
        $cart_table = $wpdb->prefix . SCR_TABLE;
        $log_table  = $wpdb->prefix . SCR_LOG_TABLE;

        return [
            'abandoned'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$cart_table` WHERE status = 'abandoned'" ), // phpcs:ignore
            'recovered'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$cart_table` WHERE status = 'recovered'" ), // phpcs:ignore
            'sent_today'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$log_table` WHERE DATE(sent_at) = CURDATE()" ), // phpcs:ignore
            'total_sent'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$log_table`" ), // phpcs:ignore
            'recovery_rate'   => self::get_recovery_rate(),
        ];
    }

    private static function get_recovery_rate(): string {
        global $wpdb;
        $table    = $wpdb->prefix . SCR_TABLE;
        $total    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$table` WHERE status IN ('abandoned','recovered')" ); // phpcs:ignore
        $recovered = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$table` WHERE status = 'recovered'" ); // phpcs:ignore
        if ( ! $total ) return '0%';
        return round( ( $recovered / $total ) * 100, 1 ) . '%';
    }

    // ─────────────────────────────────────────────────────────────────────────
    // עזר פנימי
    // ─────────────────────────────────────────────────────────────────────────

    private static function validate_step( int $step ): int {
        return in_array( $step, self::$allowed_steps, true ) ? $step : 0;
    }
}
