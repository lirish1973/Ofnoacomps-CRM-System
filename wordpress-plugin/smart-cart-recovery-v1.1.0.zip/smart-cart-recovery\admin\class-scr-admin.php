<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SCR_Admin {

    public static function init(): void {
        add_action( 'admin_menu',            [ __CLASS__, 'register_menu' ] );
        add_action( 'admin_init',            [ __CLASS__, 'register_settings' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_assets' ] );
        add_action( 'wp_ajax_scr_test_send', [ __CLASS__, 'ajax_test_send' ] );
    }

    public static function register_menu(): void {
        add_menu_page(
            'Smart Cart Recovery',
            'Cart Recovery',
            'manage_woocommerce',
            'smart-cart-recovery',
            [ __CLASS__, 'page_dashboard' ],
            'dashicons-cart',
            56
        );
        add_submenu_page( 'smart-cart-recovery', 'דשבורד',          'דשבורד',           'manage_woocommerce', 'smart-cart-recovery', [ __CLASS__, 'page_dashboard' ] );
        add_submenu_page( 'smart-cart-recovery', 'הגדרות',          'הגדרות',           'manage_woocommerce', 'scr-settings',        [ __CLASS__, 'page_settings' ] );
        add_submenu_page( 'smart-cart-recovery', 'תבניות הודעות',   'תבניות הודעות',   'manage_woocommerce', 'scr-templates',       [ __CLASS__, 'page_templates' ] );
        add_submenu_page( 'smart-cart-recovery', 'יומן שליחות',     'יומן שליחות',     'manage_woocommerce', 'scr-log',             [ __CLASS__, 'page_log' ] );
    }

    public static function register_settings(): void {
        // ✅ תיקון: שתי הקבוצות משתמשות בשם אופציה אחד – callback אחד מונע כפילות
        register_setting( 'scr_settings_group',  'scr_settings', [ 'sanitize_callback' => [ __CLASS__, 'sanitize_settings' ] ] );
        register_setting( 'scr_templates_group', 'scr_settings' ); // ✅ ללא sanitize_callback כפול
    }

    public static function sanitize_settings( array $input ): array {
        $current      = (array) get_option( 'scr_settings', [] );
        $email_fields = [ 'email_from' ];
        $bool_fields  = [ 'enable_whatsapp', 'enable_sms', 'enable_email', 'enable_step1', 'enable_step2', 'enable_step3', 'delete_data_on_uninstall' ];

        // אפס את שדות ה-checkbox (כי אם לא מסומנים הם לא נשלחים כלל)
        foreach ( $bool_fields as $field ) {
            $current[ $field ] = 0;
        }

        foreach ( $input as $key => $value ) {
            if ( is_array( $value ) ) {
                $current[ $key ] = array_map( 'sanitize_text_field', $value );
            } elseif ( in_array( $key, $bool_fields, true ) ) {
                // ✅ שדות checkbox – רק 0/1
                $current[ $key ] = 1;
            } elseif ( in_array( $key, $email_fields, true ) ) {
                // ✅ תיקון: שדות אימייל – sanitize_email
                $current[ $key ] = sanitize_email( $value );
            } elseif ( str_contains( $key, '_template_' ) || str_contains( $key, '_subject_' ) ) {
                // תבניות – מותר HTML מסוים
                $current[ $key ] = wp_kses_post( $value );
            } else {
                $current[ $key ] = sanitize_text_field( $value );
            }
        }

        return $current;
    }

    public static function enqueue_assets( string $hook ): void {
        // ✅ תיקון: בדיקה מדויקת יותר של שם הדף
        if ( ! str_contains( $hook, 'smart-cart-recovery' ) && ! str_contains( $hook, 'scr-' ) ) return;

        wp_enqueue_style(  'scr-admin', SCR_URL . 'assets/css/admin.css', [], SCR_VERSION );
        wp_enqueue_script( 'scr-admin', SCR_URL . 'assets/js/admin.js',  [ 'jquery' ], SCR_VERSION, true );
        wp_localize_script( 'scr-admin', 'SCR', [
            'nonce'    => wp_create_nonce( 'scr_nonce' ),
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'i18n'     => [
                'testing'       => __( 'שולח...', 'smart-cart-recovery' ),
                'test_btn'      => __( '🧪 שלח הודעת בדיקה', 'smart-cart-recovery' ),
                'running'       => __( 'מריץ...', 'smart-cart-recovery' ),
                'run_btn'       => __( '▶️ הרץ עכשיו', 'smart-cart-recovery' ),
                'ajax_error'    => __( 'שגיאת תקשורת', 'smart-cart-recovery' ),
            ],
        ] );
    }

    // ═══════════════════════════════════════════════════════════════════════
    // דשבורד
    // ═══════════════════════════════════════════════════════════════════════

    public static function page_dashboard(): void {
        $stats      = SCR_DB::get_stats();
        $next       = wp_next_scheduled( 'scr_process_carts' );
        $last_run   = get_option( 'scr_last_cron_run', '' );
        $opts       = (array) get_option( 'scr_settings', [] );
        ?>
        <div class="wrap scr-wrap" dir="rtl">
            <h1>🛒 Smart Cart Recovery – דשבורד</h1>

            <div class="scr-stats-grid">
                <div class="scr-stat-card scr-stat-abandoned">
                    <span class="scr-stat-number"><?php echo esc_html( $stats['abandoned'] ); ?></span>
                    <span class="scr-stat-label">עגלות נטושות פתוחות</span>
                </div>
                <div class="scr-stat-card scr-stat-recovered">
                    <span class="scr-stat-number"><?php echo esc_html( $stats['recovered'] ); ?></span>
                    <span class="scr-stat-label">עגלות שוחזרו</span>
                </div>
                <div class="scr-stat-card scr-stat-today">
                    <span class="scr-stat-number"><?php echo esc_html( $stats['sent_today'] ); ?></span>
                    <span class="scr-stat-label">הודעות נשלחו היום</span>
                </div>
                <div class="scr-stat-card scr-stat-total">
                    <span class="scr-stat-number"><?php echo esc_html( $stats['total_sent'] ); ?></span>
                    <span class="scr-stat-label">סה"כ הודעות</span>
                </div>
                <div class="scr-stat-card scr-stat-rate">
                    <span class="scr-stat-number"><?php echo esc_html( $stats['recovery_rate'] ); ?></span>
                    <span class="scr-stat-label">אחוז שחזור</span>
                </div>
            </div>

            <div class="scr-card">
                <h2>⏱️ Cron Job</h2>
                <p>הרצה הבאה: <strong>
                    <?php echo $next
                        ? esc_html( human_time_diff( $next ) . ' מעכשיו (' . date_i18n( 'H:i:s', $next ) . ')' )
                        : '<span style="color:#ef4444;">לא מתוזמן!</span>'; ?>
                </strong></p>
                <?php if ( $last_run ) : ?>
                <p>הרצה אחרונה: <strong><?php echo esc_html( date_i18n( 'd/m/Y H:i:s', strtotime( $last_run ) ) ); ?></strong></p>
                <?php endif; ?>
                <p>
                    <button type="button" class="button button-primary scr-manual-run" data-nonce="<?php echo esc_attr( wp_create_nonce( 'scr_nonce' ) ); ?>">
                        ▶️ הרץ עכשיו
                    </button>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=scr-log' ) ); ?>" class="button">
                        📋 ראה יומן שליחות
                    </a>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=scr-settings' ) ); ?>" class="button">
                        ⚙️ הגדרות
                    </a>
                </p>
                <div id="scr-manual-result" style="display:none;margin-top:8px;"></div>
            </div>

            <div class="scr-card">
                <h2>📋 Sequence פעיל</h2>
                <div class="scr-sequence">
                    <?php
                    $steps = [
                        1 => [ 'label' => 'שלב 1 – שעה אחרי',  'hours' => 1 ],
                        2 => [ 'label' => 'שלב 2 – יום אחרי',   'hours' => 24 ],
                        3 => [ 'label' => 'שלב 3 – 3 ימים אחרי', 'hours' => 72 ],
                    ];
                    foreach ( $steps as $step => $info ) :
                        $enabled = ! empty( $opts[ "enable_step{$step}" ] );
                    ?>
                    <div class="scr-step <?php echo $enabled ? 'scr-step-enabled' : 'scr-step-disabled'; ?>">
                        <div class="scr-step-header">
                            <strong><?php echo esc_html( $info['label'] ); ?></strong>
                            <span class="scr-badge"><?php echo $enabled ? '✅ פעיל' : '⛔ כבוי'; ?></span>
                        </div>
                        <div class="scr-step-channels">
                            <?php foreach ( [ 'whatsapp', 'sms', 'email' ] as $ch ) : ?>
                                <span class="scr-channel <?php echo ! empty( $opts[ "enable_$ch" ] ) ? 'on' : 'off'; ?>">
                                    <?php echo esc_html( strtoupper( $ch ) ); ?>
                                </span>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php
    }

    // ═══════════════════════════════════════════════════════════════════════
    // הגדרות
    // ═══════════════════════════════════════════════════════════════════════

    public static function page_settings(): void {
        $opts = (array) get_option( 'scr_settings', [] );
        ?>
        <div class="wrap scr-wrap" dir="rtl">
            <h1>⚙️ הגדרות</h1>
            <form method="post" action="options.php">
                <?php settings_fields( 'scr_settings_group' ); ?>

                <div class="scr-card">
                    <h2>📱 WhatsApp / SMS (Twilio)</h2>
                    <table class="form-table">
                        <tr>
                            <th>Account SID</th>
                            <td><input type="text" name="scr_settings[twilio_sid]" value="<?php echo esc_attr( $opts['twilio_sid'] ?? '' ); ?>" class="regular-text" autocomplete="off" /></td>
                        </tr>
                        <tr>
                            <th>Auth Token</th>
                            <td><input type="password" name="scr_settings[twilio_token]" value="<?php echo esc_attr( $opts['twilio_token'] ?? '' ); ?>" class="regular-text" autocomplete="off" /></td>
                        </tr>
                        <tr>
                            <th>מספר WhatsApp (From)</th>
                            <td>
                                <input type="text" name="scr_settings[twilio_wa_from]" value="<?php echo esc_attr( $opts['twilio_wa_from'] ?? 'whatsapp:+14155238886' ); ?>" class="regular-text" />
                                <p class="description">לדוגמה: <code>whatsapp:+14155238886</code> (Twilio Sandbox) או המספר שלך</p>
                            </td>
                        </tr>
                        <tr>
                            <th>מספר SMS (From)</th>
                            <td>
                                <input type="text" name="scr_settings[twilio_sms_from]" value="<?php echo esc_attr( $opts['twilio_sms_from'] ?? '' ); ?>" class="regular-text" />
                            </td>
                        </tr>
                    </table>
                    <button type="button" class="button scr-test-btn" data-channel="whatsapp" data-nonce="<?php echo esc_attr( wp_create_nonce( 'scr_nonce' ) ); ?>">
                        🧪 שלח הודעת בדיקה (WhatsApp)
                    </button>
                    &nbsp;
                    <button type="button" class="button scr-test-btn" data-channel="sms" data-nonce="<?php echo esc_attr( wp_create_nonce( 'scr_nonce' ) ); ?>">
                        🧪 שלח הודעת בדיקה (SMS)
                    </button>
                    <div class="scr-test-result"></div>
                </div>

                <div class="scr-card">
                    <h2>📧 אימייל</h2>
                    <table class="form-table">
                        <tr>
                            <th>שם השולח</th>
                            <td><input type="text"  name="scr_settings[email_from_name]" value="<?php echo esc_attr( $opts['email_from_name'] ?? get_bloginfo( 'name' ) ); ?>" class="regular-text" /></td>
                        </tr>
                        <tr>
                            <th>כתובת שולח</th>
                            <td><input type="email" name="scr_settings[email_from]" value="<?php echo esc_attr( $opts['email_from'] ?? get_option( 'admin_email' ) ); ?>" class="regular-text" /></td>
                        </tr>
                    </table>
                </div>

                <div class="scr-card">
                    <h2>📣 ערוצים פעילים</h2>
                    <table class="form-table">
                        <tr><th>WhatsApp</th><td><label><input type="checkbox" name="scr_settings[enable_whatsapp]" value="1" <?php checked( ! empty( $opts['enable_whatsapp'] ) ); ?> /> הפעל שליחת WhatsApp</label></td></tr>
                        <tr><th>SMS</th>      <td><label><input type="checkbox" name="scr_settings[enable_sms]"      value="1" <?php checked( ! empty( $opts['enable_sms'] ) ); ?> /> הפעל שליחת SMS</label></td></tr>
                        <tr><th>אימייל</th>  <td><label><input type="checkbox" name="scr_settings[enable_email]"    value="1" <?php checked( ! empty( $opts['enable_email'] ) ); ?> /> הפעל שליחת אימייל</label></td></tr>
                    </table>
                </div>

                <div class="scr-card">
                    <h2>📋 שלבי Sequence</h2>
                    <table class="form-table">
                        <tr><th>שלב 1 (שעה)</th>   <td><label><input type="checkbox" name="scr_settings[enable_step1]" value="1" <?php checked( ! empty( $opts['enable_step1'] ) ); ?> /> פעיל</label></td></tr>
                        <tr><th>שלב 2 (יום)</th>    <td><label><input type="checkbox" name="scr_settings[enable_step2]" value="1" <?php checked( ! empty( $opts['enable_step2'] ) ); ?> /> פעיל</label></td></tr>
                        <tr><th>שלב 3 (3 ימים)</th> <td><label><input type="checkbox" name="scr_settings[enable_step3]" value="1" <?php checked( ! empty( $opts['enable_step3'] ) ); ?> /> פעיל</label></td></tr>
                    </table>
                </div>

                <div class="scr-card">
                    <h2>🗑️ מחיקת נתונים</h2>
                    <table class="form-table">
                        <tr>
                            <th>מחיקה בעת הסרת הפלאגין</th>
                            <td>
                                <label>
                                    <input type="checkbox" name="scr_settings[delete_data_on_uninstall]" value="1" <?php checked( ! empty( $opts['delete_data_on_uninstall'] ) ); ?> />
                                    מחק את כל הנתונים (טבלאות ולוג) בעת הסרת הפלאגין
                                </label>
                                <p class="description" style="color:#ef4444;">⚠️ פעולה זו אינה ניתנת לביטול!</p>
                            </td>
                        </tr>
                    </table>
                </div>

                <?php submit_button( 'שמור הגדרות' ); ?>
            </form>
        </div>
        <?php
    }

    // ═══════════════════════════════════════════════════════════════════════
    // תבניות
    // ═══════════════════════════════════════════════════════════════════════

    public static function page_templates(): void {
        $opts     = (array) get_option( 'scr_settings', [] );
        $channels = [ 'whatsapp' => 'WhatsApp', 'sms' => 'SMS', 'email' => 'אימייל' ];
        $steps    = [
            1 => 'שלב 1 – שעה אחרי',
            2 => 'שלב 2 – יום אחרי',
            3 => 'שלב 3 – 3 ימים אחרי',
        ];
        ?>
        <div class="wrap scr-wrap" dir="rtl">
            <h1>📝 תבניות הודעות</h1>
            <p class="description">
                משתנים זמינים: <code>{name}</code> <code>{cart_url}</code> <code>{cart_total}</code> <code>{items}</code> <code>{shop_name}</code>
            </p>

            <form method="post" action="options.php">
                <?php settings_fields( 'scr_settings_group' ); ?>

                <?php foreach ( $steps as $step => $step_label ) : ?>
                <div class="scr-card">
                    <h2><?php echo esc_html( $step_label ); ?></h2>

                    <div class="scr-template-group">
                        <label><strong>📧 נושא אימייל</strong></label>
                        <input type="text"
                            name="scr_settings[email_subject_step<?php echo esc_attr( $step ); ?>]"
                            value="<?php echo esc_attr( $opts[ "email_subject_step{$step}" ] ?? SCR_Sender::default_subject( $step ) ); ?>"
                            class="large-text" />
                    </div>

                    <?php foreach ( $channels as $ch => $ch_label ) : ?>
                    <div class="scr-template-group">
                        <label><strong><?php echo esc_html( $ch_label ); ?></strong></label>
                        <textarea
                            name="scr_settings[<?php echo esc_attr( "{$ch}_template_step{$step}" ); ?>]"
                            rows="5"
                            class="large-text"
                        ><?php echo esc_textarea( $opts[ "{$ch}_template_step{$step}" ] ?? SCR_Sender::default_template( $step, $ch ) ); ?></textarea>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endforeach; ?>

                <?php submit_button( 'שמור תבניות' ); ?>
            </form>
        </div>
        <?php
    }

    // ═══════════════════════════════════════════════════════════════════════
    // יומן שליחות עם Pagination
    // ═══════════════════════════════════════════════════════════════════════

    public static function page_log(): void {
        $limit       = 30;
        $page        = max( 1, intval( $_GET['paged'] ?? 1 ) ); // phpcs:ignore WordPress.Security.NonceVerification
        $offset      = ( $page - 1 ) * $limit;
        $logs        = SCR_DB::get_log( $limit, $offset );
        $total       = SCR_DB::get_total_log_count();
        $total_pages = (int) ceil( $total / $limit );

        $channel_icon = [ 'whatsapp' => '📱', 'sms' => '💬', 'email' => '📧' ];
        ?>
        <div class="wrap scr-wrap" dir="rtl">
            <h1>📋 יומן שליחות</h1>
            <p>סה"כ: <strong><?php echo esc_html( $total ); ?></strong> רשומות</p>

            <table class="widefat fixed striped scr-log-table">
                <thead>
                    <tr>
                        <th>תאריך/שעה</th>
                        <th>שם</th>
                        <th>ערוץ</th>
                        <th>שלב</th>
                        <th>נמען</th>
                        <th>סטטוס</th>
                        <th>סה"כ עגלה</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ( empty( $logs ) ) : ?>
                    <tr><td colspan="7" style="text-align:center">אין רשומות להצגה</td></tr>
                <?php else : ?>
                    <?php foreach ( $logs as $log ) : ?>
                    <tr>
                        <td><?php echo esc_html( date_i18n( 'd/m/Y H:i', strtotime( $log->sent_at ) ) ); ?></td>
                        <td><?php echo esc_html( $log->first_name ?: '–' ); ?></td>
                        <td><?php echo esc_html( ( $channel_icon[ $log->channel ] ?? '' ) . ' ' . strtoupper( $log->channel ) ); ?></td>
                        <td>שלב <?php echo intval( $log->step ); ?></td>
                        <td><code><?php echo esc_html( $log->recipient ); ?></code></td>
                        <td class="scr-status-<?php echo esc_attr( $log->status ); ?>">
                            <?php echo $log->status === 'sent' ? '✅ נשלח' : '❌ שגיאה'; ?>
                        </td>
                        <td><?php echo $log->cart_total ? wp_kses_post( wc_price( $log->cart_total ) ) : '–'; ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>

            <?php if ( $total_pages > 1 ) : ?>
            <div class="tablenav bottom" style="margin-top:16px;">
                <div class="tablenav-pages">
                    <?php
                    $base_url = admin_url( 'admin.php?page=scr-log' );
                    echo paginate_links( [
                        'base'      => add_query_arg( 'paged', '%#%', $base_url ),
                        'format'    => '',
                        'current'   => $page,
                        'total'     => $total_pages,
                        'prev_text' => '&laquo;',
                        'next_text' => '&raquo;',
                    ] );
                    ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }

    // ═══════════════════════════════════════════════════════════════════════
    // AJAX – שליחת בדיקה
    // ═══════════════════════════════════════════════════════════════════════

    public static function ajax_test_send(): void {
        check_ajax_referer( 'scr_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_woocommerce' ) ) wp_die( 'Unauthorized', 403 );

        $phone   = sanitize_text_field( $_POST['phone']   ?? '' );
        $channel = sanitize_key( $_POST['channel'] ?? 'whatsapp' );

        if ( ! in_array( $channel, [ 'whatsapp', 'sms', 'email' ], true ) ) {
            wp_send_json_error( [ 'message' => 'ערוץ לא תקין' ] );
            return;
        }

        // עגלה מדומה לבדיקה
        $fake_cart = (object) [
            'id'            => 0,
            'first_name'    => 'בדיקה',
            'phone'         => $phone,
            'email'         => get_option( 'admin_email' ),
            'cart_total'    => 99.90,
            'cart_url'      => wc_get_cart_url(),
            'cart_contents' => wp_json_encode( [ [ 'name' => 'מוצר לדוגמה', 'qty' => 1, 'price' => '₪99.90', 'image' => '' ] ], JSON_UNESCAPED_UNICODE ),
        ];

        $result = false;
        if ( $channel === 'whatsapp' ) {
            $result = SCR_Sender::send_whatsapp( $fake_cart, 1 );
        } elseif ( $channel === 'sms' ) {
            $result = SCR_Sender::send_sms( $fake_cart, 1 );
        } elseif ( $channel === 'email' ) {
            $result = SCR_Sender::send_email( $fake_cart, 1 );
        }

        wp_send_json( [
            'success' => $result,
            'message' => $result
                ? __( 'נשלח בהצלחה!', 'smart-cart-recovery' )
                : __( 'שגיאה בשליחה, בדוק את הגדרות Twilio', 'smart-cart-recovery' ),
        ] );
    }
}
