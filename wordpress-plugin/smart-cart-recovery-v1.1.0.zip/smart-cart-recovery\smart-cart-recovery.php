<?php
/**
 * Plugin Name: Smart Cart Recovery
 * Plugin URI:  https://your-site.com
 * Description: מעקב ושחזור עגלות נטושות דרך WhatsApp, SMS ואימייל – אוטומטי לחלוטין
 * Version:     1.1.0
 * Author:      Your Name
 * Text Domain: smart-cart-recovery
 * Requires WC: 5.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SCR_VERSION',   '1.1.0' );
define( 'SCR_PATH',      plugin_dir_path( __FILE__ ) );
define( 'SCR_URL',       plugin_dir_url( __FILE__ ) );
define( 'SCR_TABLE',     'scr_abandoned_carts' );
define( 'SCR_LOG_TABLE', 'scr_send_log' );

require_once SCR_PATH . 'includes/class-scr-db.php';
require_once SCR_PATH . 'includes/class-scr-tracker.php';
require_once SCR_PATH . 'includes/class-scr-sender.php';
require_once SCR_PATH . 'includes/class-scr-cron.php';
require_once SCR_PATH . 'admin/class-scr-admin.php';

register_activation_hook( __FILE__, 'scr_on_activate' );
register_deactivation_hook( __FILE__, [ 'SCR_Cron', 'unschedule' ] );

function scr_on_activate() {
    SCR_DB::create_tables();
    // לוודא שה-cron יקבע מחדש לאחר הפעלה
    wp_clear_scheduled_hook( 'scr_process_carts' );
}

add_action( 'plugins_loaded', 'scr_init' );
function scr_init() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', function () {
            echo '<div class="notice notice-error"><p><strong>Smart Cart Recovery:</strong> '
                . esc_html__( 'WooCommerce חייב להיות מותקן ופעיל כדי שהפלאגין יעבוד.', 'smart-cart-recovery' )
                . '</p></div>';
        } );
        return;
    }

    // עדכון מסד נתונים אם הגרסה השתנתה
    if ( get_option( 'scr_db_version' ) !== SCR_VERSION ) {
        SCR_DB::create_tables();
    }

    SCR_Tracker::init();
    SCR_Cron::init();
    SCR_Admin::init();
}
