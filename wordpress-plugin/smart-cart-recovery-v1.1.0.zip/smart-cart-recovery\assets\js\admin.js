/* global SCR, $ */
jQuery( function ( $ ) {

    // ─────────────────────────────────────────────────────────────────────
    // כפתור בדיקת שליחה
    // ─────────────────────────────────────────────────────────────────────
    $( document ).on( 'click', '.scr-test-btn', function () {
        var $btn     = $( this );
        var channel  = $btn.data( 'channel' );
        var phone    = '';

        if ( channel === 'whatsapp' || channel === 'sms' ) {
            phone = prompt( 'הזן מספר טלפון ישראלי לשליחת הבדיקה (לדוגמה: 0501234567):' );
            if ( ! phone ) return;
        }

        $btn.prop( 'disabled', true ).text( SCR.i18n.testing || 'שולח...' );

        var $result = $btn.closest( '.scr-card' ).find( '.scr-test-result' );

        $.post( SCR.ajax_url, {
            action:  'scr_test_send',
            nonce:   SCR.nonce,
            channel: channel,
            phone:   phone,
        }, function ( res ) {
            $result
                .removeClass( 'success error' )
                .addClass( res.success ? 'success' : 'error' )
                .text( res.message )
                .show();
            $btn.prop( 'disabled', false ).text( SCR.i18n.test_btn || '🧪 שלח הודעת בדיקה' );
        } ).fail( function () {
            $result.removeClass( 'success' ).addClass( 'error' ).text( SCR.i18n.ajax_error || 'שגיאת תקשורת' ).show();
            $btn.prop( 'disabled', false ).text( SCR.i18n.test_btn || '🧪 שלח הודעת בדיקה' );
        } );
    } );

    // ─────────────────────────────────────────────────────────────────────
    // הרצת Cron ידנית מהדשבורד
    // ─────────────────────────────────────────────────────────────────────
    $( document ).on( 'click', '.scr-manual-run', function () {
        var $btn    = $( this );
        var nonce   = $btn.data( 'nonce' );
        var $result = $( '#scr-manual-result' );

        $btn.prop( 'disabled', true ).text( SCR.i18n.running || 'מריץ...' );

        $.post( SCR.ajax_url, {
            action: 'scr_manual_run',
            nonce:  nonce,
        }, function ( res ) {
            $result
                .removeClass( 'success error' )
                .addClass( res.success ? 'success' : 'error' )
                .html( res.success
                    ? '✅ ' + res.data.message + ' (' + res.data.time + ')'
                    : '❌ ' + ( res.data || 'שגיאה לא ידועה' )
                )
                .show();
            $btn.prop( 'disabled', false ).text( SCR.i18n.run_btn || '▶️ הרץ עכשיו' );
        } ).fail( function () {
            $result.addClass( 'error' ).text( SCR.i18n.ajax_error || 'שגיאת תקשורת' ).show();
            $btn.prop( 'disabled', false ).text( SCR.i18n.run_btn || '▶️ הרץ עכשיו' );
        } );
    } );

} );
