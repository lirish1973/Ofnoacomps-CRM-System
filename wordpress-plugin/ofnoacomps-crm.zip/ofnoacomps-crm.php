﻿<?php
/**
 * Plugin Name: Ofnoacomps CRM
 * Plugin URI:  https://www.ofnoacomps.co.il
 * Description: מערכת CRM מלאה לניהול לידים, לקוחות, עסקאות ודוחות עם מעקב מקור תנועה.
 * Version:     1.3.0
 * Author:      Ofnoacomps
 * Text Domain: ofnoacomps-crm
 * Domain Path: /languages
 */

defined('ABSPATH') || exit;

define('OFNOACOMPS_CRM_VERSION', '1.3.0');
define('OFNOACOMPS_CRM_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('OFNOACOMPS_CRM_PLUGIN_URL', plugin_dir_url(__FILE__));
define('OFNOACOMPS_CRM_PLUGIN_FILE', __FILE__);

// Auto-updater (checks GitHub for major + minor + patch updates)
require_once OFNOACOMPS_CRM_PLUGIN_DIR . 'includes/class-github-updater.php';
add_action( 'init', function () {
    new Ofnoacomps_GitHub_Updater( __FILE__, 'ofnoacomps-crm', OFNOACOMPS_CRM_VERSION );
} );

// Autoload classes
spl_autoload_register(function ($class) {
    $prefix = 'Ofnoacomps_CRM_';
    if (strpos($class, $prefix) !== 0) return;

    $map = [
        'Ofnoacomps_CRM_Database'   => 'includes/class-database.php',
        'Ofnoacomps_CRM_Lead'       => 'includes/class-lead.php',
        'Ofnoacomps_CRM_Customer'   => 'includes/class-customer.php',
        'Ofnoacomps_CRM_Deal'       => 'includes/class-deal.php',
        'Ofnoacomps_CRM_Pipeline'   => 'includes/class-pipeline.php',
        'Ofnoacomps_CRM_Activity'   => 'includes/class-activity.php',
        'Ofnoacomps_CRM_Tracker'    => 'includes/class-tracker.php',
        'Ofnoacomps_CRM_Reports'    => 'includes/class-reports.php',
        'Ofnoacomps_CRM_Admin'      => 'admin/class-admin.php',
        'Ofnoacomps_CRM_REST_API'   => 'api/class-rest-api.php',
    ];

    if (isset($map[$class])) {
        require_once OFNOACOMPS_CRM_PLUGIN_DIR . $map[$class];
    }
});

// Activation / Deactivation
register_activation_hook(__FILE__, ['Ofnoacomps_CRM_Database', 'install']);
register_deactivation_hook(__FILE__, ['Ofnoacomps_CRM_Database', 'deactivate']);

/**
 * Bootstrap the plugin.
 */
function ofnoacomps_crm_init() {
    // Admin
    if (is_admin()) {
        new Ofnoacomps_CRM_Admin();
    }

    // REST API
    add_action('rest_api_init', function () {
        $api = new Ofnoacomps_CRM_REST_API();
        $api->register_routes();
    });

    // Frontend tracker (enqueue on all pages)
    add_action('wp_enqueue_scripts', 'ofnoacomps_crm_enqueue_tracker');

    // Hook into Contact Form 7
    add_action('wpcf7_mail_sent', 'ofnoacomps_crm_capture_cf7_lead');

    // Hook into WPForms
    add_action('wpforms_process_complete', 'ofnoacomps_crm_capture_wpforms_lead', 10, 4);

    // Generic hook — other plugins can call this
    // do_action('ofnoacomps_crm_capture_lead', $data);
    add_action('ofnoacomps_crm_capture_lead', ['Ofnoacomps_CRM_Lead', 'capture'], 10, 1);
}
add_action('plugins_loaded', 'ofnoacomps_crm_init');

/**
 * Enqueue the UTM tracker script on the frontend.
 */
function ofnoacomps_crm_enqueue_tracker() {
    wp_enqueue_script(
        'ofnoacomps-crm-tracker',
        OFNOACOMPS_CRM_PLUGIN_URL . 'assets/tracker.js',
        [],
        OFNOACOMPS_CRM_VERSION,
        true
    );
    wp_localize_script('ofnoacomps-crm-tracker', 'ofnoacompsCRM', [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('ofnoacomps_crm_nonce'),
        'siteUrl' => get_site_url(),
    ]);
}

/**
 * Capture a lead from Contact Form 7.
 */
function ofnoacomps_crm_capture_cf7_lead($contact_form) {
    $submission = WPCF7_Submission::get_instance();
    if (!$submission) return;

    $posted = $submission->get_posted_data();
    $tracker = isset($_COOKIE['ofnoacomps_crm_tracker']) ? json_decode(stripslashes($_COOKIE['ofnoacomps_crm_tracker']), true) : [];

    $name_parts = explode(' ', sanitize_text_field($posted['your-name'] ?? ''), 2);

    Ofnoacomps_CRM_Lead::create([
        'first_name'   => $name_parts[0] ?? '',
        'last_name'    => $name_parts[1] ?? '',
        'email'        => sanitize_email($posted['your-email'] ?? ''),
        'phone'        => sanitize_text_field($posted['your-phone'] ?? $posted['tel-788'] ?? ''),
        'message'      => sanitize_textarea_field($posted['your-message'] ?? ''),
        'form_id'      => $contact_form->id(),
        'form_name'    => $contact_form->title(),
        'page_url'     => sanitize_url($tracker['page_url'] ?? wp_get_referer()),
        'source'       => sanitize_text_field($tracker['source'] ?? 'direct'),
        'medium'       => sanitize_text_field($tracker['medium'] ?? ''),
        'campaign'     => sanitize_text_field($tracker['campaign'] ?? ''),
        'utm_term'     => sanitize_text_field($tracker['utm_term'] ?? ''),
        'utm_content'  => sanitize_text_field($tracker['utm_content'] ?? ''),
        'referrer'     => sanitize_url($tracker['referrer'] ?? ''),
        'landing_page' => sanitize_url($tracker['landing_page'] ?? ''),
        'device_type'  => sanitize_text_field($tracker['device_type'] ?? ''),
        'ip_address'   => ofnoacomps_crm_get_ip(),
    ]);
}

/**
 * Capture a lead from WPForms.
 */
function ofnoacomps_crm_capture_wpforms_lead($fields, $entry, $form_data, $entry_id) {
    $tracker = isset($_COOKIE['ofnoacomps_crm_tracker']) ? json_decode(stripslashes($_COOKIE['ofnoacomps_crm_tracker']), true) : [];
    $email = $phone = $name = '';

    foreach ($fields as $field) {
        if (in_array($field['type'], ['email'])) $email = $field['value'];
        if (in_array($field['type'], ['phone'])) $phone = $field['value'];
        if (in_array($field['type'], ['name'])) $name = $field['value_raw'] ?? $field['value'];
    }

    $name_parts = explode(' ', sanitize_text_field($name), 2);

    Ofnoacomps_CRM_Lead::create([
        'first_name'   => $name_parts[0] ?? '',
        'last_name'    => $name_parts[1] ?? '',
        'email'        => sanitize_email($email),
        'phone'        => sanitize_text_field($phone),
        'form_id'      => $form_data['id'],
        'form_name'    => $form_data['settings']['form_title'] ?? '',
        'source'       => sanitize_text_field($tracker['source'] ?? 'direct'),
        'medium'       => sanitize_text_field($tracker['medium'] ?? ''),
        'campaign'     => sanitize_text_field($tracker['campaign'] ?? ''),
        'utm_term'     => sanitize_text_field($tracker['utm_term'] ?? ''),
        'utm_content'  => sanitize_text_field($tracker['utm_content'] ?? ''),
        'referrer'     => sanitize_url($tracker['referrer'] ?? ''),
        'landing_page' => sanitize_url($tracker['landing_page'] ?? ''),
        'ip_address'   => ofnoacomps_crm_get_ip(),
    ]);
}

/**
 * Get visitor IP.
 */
function ofnoacomps_crm_get_ip() {
    foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $key) {
        if (!empty($_SERVER[$key])) {
            return sanitize_text_field(explode(',', $_SERVER[$key])[0]);
        }
    }
    return '';
}
