<?php defined('ABSPATH') || exit; ?>
<div class="wrap hoco-crm-wrap">
<div class="hoco-page-header"><h1>⚙️ הגדרות CRM</h1></div>

<form method="post" style="max-width:560px;">
    <?php wp_nonce_field('hoco_settings', 'hoco_settings_nonce'); ?>

    <div class="hoco-detail-card">
        <h3>כללי</h3>
        <div class="hoco-form-row">
            <label>סמל מטבע</label>
            <input type="text" name="currency" value="<?php echo esc_attr($currency); ?>" style="max-width:80px;">
            <p style="color:#64748b;font-size:12px;">לדוגמה: ₪ / $ / €</p>
        </div>
        <div class="hoco-form-row">
            <label>אימייל להתראות לידים חדשים</label>
            <input type="email" name="notify_email" value="<?php echo esc_attr($notify_email); ?>">
        </div>
    </div>

    <div class="hoco-detail-card" style="margin-top:16px;">
        <h3>מידע טכני</h3>
        <div class="hoco-field-row"><span class="hoco-field-label">גרסה</span><span class="hoco-field-value"><?php echo HOCO_CRM_VERSION; ?></span></div>
        <div class="hoco-field-row"><span class="hoco-field-label">REST API</span><span class="hoco-field-value"><code><?php echo rest_url('hoco-crm/v1'); ?></code></span></div>
        <div class="hoco-field-row">
            <span class="hoco-field-label">Endpoint ציבורי (capture)</span>
            <span class="hoco-field-value"><code><?php echo rest_url('hoco-crm/v1/capture'); ?></code></span>
        </div>
    </div>

    <div class="hoco-detail-card" style="margin-top:16px;">
        <h3>אינטגרציות זמינות</h3>
        <p style="font-size:13px;color:#475569;">הפלאגין מחובר אוטומטית ל:</p>
        <ul style="font-size:13px;color:#475569;padding-right:20px;">
            <li><strong>Contact Form 7</strong> — לידים נקלטים אוטומטית מכל הטפסים</li>
            <li><strong>WPForms</strong> — תמיכה מובנית</li>
            <li><strong>API ציבורי</strong> — <code>POST /hoco-crm/v1/capture</code> לאינטגרציות חיצוניות</li>
            <li><strong>JavaScript</strong> — <code>HocoCRM.submitLead({...})</code> מכל טופס מותאם</li>
        </ul>
    </div>

    <button type="submit" class="hoco-btn hoco-btn-primary" style="margin-top:16px;">שמור הגדרות</button>
</form>
</div>
