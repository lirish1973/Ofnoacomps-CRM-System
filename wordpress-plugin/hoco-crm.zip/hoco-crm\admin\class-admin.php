<?php
defined('ABSPATH') || exit;

class Hoco_CRM_Admin {

    public function __construct() {
        add_action('admin_menu',            [$this, 'register_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('admin_init',            [$this, 'handle_actions']);
    }

    public function register_menu(): void {
        add_menu_page(
            'Hoco CRM',
            'Hoco CRM',
            'edit_posts',
            'hoco-crm',
            [$this, 'page_dashboard'],
            'dashicons-groups',
            26
        );

        add_submenu_page('hoco-crm', 'דשבורד',      'דשבורד',      'edit_posts', 'hoco-crm',           [$this, 'page_dashboard']);
        add_submenu_page('hoco-crm', 'לידים',        'לידים',        'edit_posts', 'hoco-crm-leads',     [$this, 'page_leads']);
        add_submenu_page('hoco-crm', 'לקוחות',      'לקוחות',      'edit_posts', 'hoco-crm-customers', [$this, 'page_customers']);
        add_submenu_page('hoco-crm', 'Pipeline',     'Pipeline',     'edit_posts', 'hoco-crm-pipeline',  [$this, 'page_pipeline']);
        add_submenu_page('hoco-crm', 'דוחות',        'דוחות',        'edit_posts', 'hoco-crm-reports',   [$this, 'page_reports']);
        add_submenu_page('hoco-crm', 'הגדרות',      'הגדרות',      'manage_options', 'hoco-crm-settings', [$this, 'page_settings']);
    }

    public function enqueue_assets(string $hook): void {
        if (strpos($hook, 'hoco-crm') === false) return;

        wp_enqueue_style(
            'hoco-crm-admin',
            HOCO_CRM_PLUGIN_URL . 'admin/assets/admin.css',
            [],
            HOCO_CRM_VERSION
        );

        // Chart.js from CDN
        wp_enqueue_script('chartjs', 'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js', [], null, true);

        wp_enqueue_script(
            'hoco-crm-admin',
            HOCO_CRM_PLUGIN_URL . 'admin/assets/admin.js',
            ['jquery', 'chartjs'],
            HOCO_CRM_VERSION,
            true
        );

        wp_localize_script('hoco-crm-admin', 'hocoCRMAdmin', [
            'apiBase'  => rest_url('hoco-crm/v1'),
            'nonce'    => wp_create_nonce('wp_rest'),
            'currency' => get_option('hoco_crm_currency', '₪'),
            'ajaxUrl'  => admin_url('admin-ajax.php'),
        ]);
    }

    public function handle_actions(): void {
        // Bulk delete leads
        if (isset($_POST['hoco_bulk_action']) && $_POST['hoco_bulk_action'] === 'delete_leads') {
            check_admin_referer('hoco_bulk_action');
            $ids = array_map('intval', (array) ($_POST['lead_ids'] ?? []));
            foreach ($ids as $id) Hoco_CRM_Lead::delete($id);
            wp_redirect(admin_url('admin.php?page=hoco-crm-leads&deleted=' . count($ids)));
            exit;
        }
    }

    // ── Pages ──────────────────────────────────────────────────────────────────

    public function page_dashboard(): void {
        $summary = Hoco_CRM_Reports::dashboard_summary();
        require HOCO_CRM_PLUGIN_DIR . 'admin/views/dashboard.php';
    }

    public function page_leads(): void {
        $action = sanitize_text_field($_GET['action'] ?? 'list');
        $id     = (int) ($_GET['id'] ?? 0);

        if ($action === 'view' && $id) {
            $lead       = Hoco_CRM_Lead::get($id);
            $activities = Hoco_CRM_Activity::list(['entity_type' => 'lead', 'entity_id' => $id]);
            $statuses   = Hoco_CRM_Lead::get_statuses();
            require HOCO_CRM_PLUGIN_DIR . 'admin/views/lead-detail.php';
            return;
        }

        $search   = sanitize_text_field($_GET['s'] ?? '');
        $status   = sanitize_text_field($_GET['status'] ?? '');
        $source   = sanitize_text_field($_GET['source'] ?? '');
        $paged    = max(1, (int)($_GET['paged'] ?? 1));
        $per_page = 30;
        $offset   = ($paged - 1) * $per_page;

        $leads   = Hoco_CRM_Lead::list(['search' => $search, 'status' => $status, 'source' => $source, 'limit' => $per_page, 'offset' => $offset]);
        $total   = Hoco_CRM_Lead::count(['search' => $search, 'status' => $status, 'source' => $source]);
        $pages   = ceil($total / $per_page);
        $statuses= Hoco_CRM_Lead::get_statuses();
        $sources = Hoco_CRM_Lead::get_sources();
        $users   = get_users(['role__in' => ['administrator','editor'], 'fields' => ['ID','display_name']]);

        require HOCO_CRM_PLUGIN_DIR . 'admin/views/leads.php';
    }

    public function page_customers(): void {
        $action = sanitize_text_field($_GET['action'] ?? 'list');
        $id     = (int) ($_GET['id'] ?? 0);

        if ($action === 'view' && $id) {
            $customer   = Hoco_CRM_Customer::get($id);
            $activities = Hoco_CRM_Activity::list(['entity_type' => 'customer', 'entity_id' => $id]);
            $deals      = Hoco_CRM_Deal::list(['customer_id' => $id]);
            require HOCO_CRM_PLUGIN_DIR . 'admin/views/customer-detail.php';
            return;
        }

        $search = sanitize_text_field($_GET['s'] ?? '');
        $paged  = max(1, (int)($_GET['paged'] ?? 1));
        $per_page = 30;
        $offset = ($paged - 1) * $per_page;

        $customers = Hoco_CRM_Customer::list(['search' => $search, 'limit' => $per_page, 'offset' => $offset]);
        $total     = Hoco_CRM_Customer::count();
        $pages     = ceil($total / $per_page);

        require HOCO_CRM_PLUGIN_DIR . 'admin/views/customers.php';
    }

    public function page_pipeline(): void {
        $pipelines = Hoco_CRM_Pipeline::get_all();
        $pipeline_id = (int) ($_GET['pipeline'] ?? ($pipelines[0]->id ?? 0));
        $kanban    = $pipeline_id ? Hoco_CRM_Deal::kanban($pipeline_id) : [];
        $users     = get_users(['role__in' => ['administrator','editor'], 'fields' => ['ID','display_name']]);
        require HOCO_CRM_PLUGIN_DIR . 'admin/views/pipeline.php';
    }

    public function page_reports(): void {
        $from = sanitize_text_field($_GET['from'] ?? date('Y-m-01'));
        $to   = sanitize_text_field($_GET['to']   ?? date('Y-m-d'));

        $summary      = Hoco_CRM_Reports::dashboard_summary($from, $to);
        $by_source    = Hoco_CRM_Reports::leads_by_source($from, $to);
        $by_status    = Hoco_CRM_Reports::leads_by_status();
        $funnel       = Hoco_CRM_Reports::pipeline_funnel();
        $leaderboard  = Hoco_CRM_Reports::rep_leaderboard($from, $to);
        $leads_time   = Hoco_CRM_Reports::leads_over_time($from, $to);
        $revenue_time = Hoco_CRM_Reports::revenue_over_time($from, $to);

        require HOCO_CRM_PLUGIN_DIR . 'admin/views/reports.php';
    }

    public function page_settings(): void {
        if (isset($_POST['hoco_settings_nonce']) && wp_verify_nonce($_POST['hoco_settings_nonce'], 'hoco_settings')) {
            update_option('hoco_crm_currency', sanitize_text_field($_POST['currency'] ?? '₪'));
            update_option('hoco_crm_notify_email', sanitize_email($_POST['notify_email'] ?? ''));
            echo '<div class="notice notice-success"><p>הגדרות נשמרו.</p></div>';
        }
        $currency     = get_option('hoco_crm_currency', '₪');
        $notify_email = get_option('hoco_crm_notify_email', get_option('admin_email'));
        require HOCO_CRM_PLUGIN_DIR . 'admin/views/settings.php';
    }
}
